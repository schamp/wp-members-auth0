# WP-Members / Auth0
Contributors: aschamp

Tags: membership, wp-members, authentication, auth0

Requires at least: 3.8

Tested up to: 4.5.2

Stable tag: trunk

License: MIT

License URI: https://raw.githubusercontent.com/schamp/wp-members-auth0/master/LICENSE

Wordpress Plugin for integrating the "require admin approval" feature of WP-Members and the Auth0 login plugin.

## Description 
Wordpress Plugin for integrating the "require admin approval" feature of WP-Members and the Auth0 login plugin.  Requires at least WP-Members v3.1.2 (https://wordpress.org/plugins/wp-members/) and WP-Auth0 v3.1.3 (https://wordpress.org/plugins/auth0/)

## Changelog
v1.0.0 - Initial Release
 * Integrate with the new auth0_before_login hook.
